package com.sw.command;

import com.sw.dto.MemberDto;

public interface Service {
	
	public int execute(MemberDto mdto);
	
}
